﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace RandevuNoktaClient.Authentication
{
    public class AuthHandler: AuthenticationHandler<AuthOptions>
    {
        private IConfiguration _configuration;
        public AuthHandler(IOptionsMonitor<AuthOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock, IConfiguration configuration) : base(options, logger, encoder, clock)
        {
            _configuration = configuration;
        }

        protected override Task HandleChallengeAsync(AuthenticationProperties properties)
        {
            Response.Redirect("/auth/login");
            return Task.CompletedTask;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var cookieKey = _configuration.GetSection("Auth:CookieKey").Value;
            Request.Cookies.TryGetValue(cookieKey, out var token);

            if (token == null)
            {
                return AuthenticateResult.Fail("fail");
            }
            var principal = await GetPrincipal(token);

            if (principal == null)
                return AuthenticateResult.Fail("fail");

            var identity = (ClaimsIdentity)principal.Identity;

            var ticket = new AuthenticationTicket(new ClaimsPrincipal(identity), Options.Scheme);
            return AuthenticateResult.Success(ticket);
        }


        private async Task<ClaimsPrincipal> GetPrincipal(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = (JwtSecurityToken)tokenHandler.ReadToken(token);
                if (jwtToken == null)
                    return null;

                var key = Encoding.ASCII.GetBytes(_configuration.GetSection("Auth:JWTSecret").Value);

                var parameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key)
                };

                var principal = tokenHandler.ValidateToken(token, parameters, out _);
                return principal;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
