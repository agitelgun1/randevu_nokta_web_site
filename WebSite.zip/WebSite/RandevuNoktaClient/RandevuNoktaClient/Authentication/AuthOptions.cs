﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RandevuNoktaClient.Authentication
{
    public class AuthOptions: AuthenticationSchemeOptions
    {
        public const string DefaultScheme = "RandevuNoktaScheme";
        public string Scheme => DefaultScheme;
    }
}
