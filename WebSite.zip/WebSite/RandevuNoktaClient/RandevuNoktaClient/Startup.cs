﻿using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RandevuNoktaClient.Extensions;

namespace RandevuNoktaClient
{
    public class Startup
    {
        private IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.ConfigureSingletonCollections();
            services.ConfigureMvcCoreCollection();
            services.ConfigureCompressionCollection();
            services.ConfigureCollection();
            services.AddMediatR(typeof(Startup).Assembly);
            services.ConfigureHttpClientCollections(Configuration);
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseExceptionPageEnv(env);
            app.UseStaticFiles();
            app.UseAuthentication();
            app.UseErrorMiddleware();
            app.UseMvcBuilder();
        }
    }
}