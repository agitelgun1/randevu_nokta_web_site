using Core.Services.ServiceInterface;
using Microsoft.AspNetCore.Mvc;

namespace RandevuNoktaClient.Controllers
{
    [Route("[controller]/[action]")]
    public class UserController : Controller
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        
        [HttpGet]
        public IActionResult UserInfo()
        {
            return View();
        }
    }
}