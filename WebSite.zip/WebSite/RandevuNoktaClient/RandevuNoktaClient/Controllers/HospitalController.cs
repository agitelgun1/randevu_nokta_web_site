using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Services.ServiceInterface;
using Domain.DTO;
using Domain.Entity;
using Domain.ServiceModel;
using Domain.ServiceResponse.ClinicService;
using Microsoft.AspNetCore.Mvc;

namespace RandevuNoktaClient.Controllers
{
    [Route("[controller]/[action]")]
    public class HospitalController : Controller
    {
        private readonly IHospitalService _hospitalService;


        public HospitalController(IHospitalService hospitalService)
        {
            _hospitalService = hospitalService;
        }

        [HttpGet]
        public async Task<JsonResult> HospitalDetailInfo(int clinicId)
        {
            var response = new BaseResponse<HospitalGeneralInfo>();

            var doctorList = _hospitalService.GetDoctorListByClinicId(clinicId);
            var clinicInfo = _hospitalService.GetClinicGeneralInfo(clinicId);
            var clinicComments = _hospitalService.GetClinicCommentsListByClinicId(clinicId);

            var taskList = new List<Task>
            {
                clinicInfo,
                doctorList,
                clinicComments
            };

            var task = Task.WhenAll(taskList.ToArray());

            await task;

            if (task.Status == TaskStatus.RanToCompletion)
            {
                var hospitalGeneralInfo = new HospitalGeneralInfo
                {
                    ClinicInfo = clinicInfo.Result?.Result ?? new ClinicModel(),
                    DoctorList = doctorList.Result?.Result ?? new List<DoctorModel>(),
                    ClinicComments = clinicComments.Result?.Result ?? new ClinicUsersCommentResponse(),
                    CommentPercentageByScore = clinicComments.Result?.Result?.CommentPercentageByScore
                        ?.OrderByDescending(x => x.Key).ToDictionary(x => x.Key, x => x.Value) ?? new Dictionary<int, double>()
                };
                response.Result = hospitalGeneralInfo;
                response.IsSuccess = true;
            }
            else
            {
                response.IsSuccess = false;
                response.ErrorDescription = "Bir hata oluştu lütfen sonra tekrar deneyiniz.";
            }

            return Json(response);
        }

        [HttpGet]
        public IActionResult HospitalDetail()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> List()
        {
            return View();
        }
    }
}