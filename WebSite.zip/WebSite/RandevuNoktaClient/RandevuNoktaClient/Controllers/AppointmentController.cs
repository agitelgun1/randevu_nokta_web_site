using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Services.ServiceInterface;
using Domain.DTO;
using Domain.Entity;
using Domain.ServiceModel;
using Domain.ServiceResponse.ClinicService;
using Microsoft.AspNetCore.Mvc;

namespace RandevuNoktaClient.Controllers
{
    [Route("[controller]/[action]")]
    public class AppointmentController : Controller
    {
        private readonly IAppointmentService _appointmentService;


        public AppointmentController(IAppointmentService appointmentService)
        {
            _appointmentService = appointmentService;
        }

        [HttpGet]
        public IActionResult Appointment()
        {
            return View();
        }
    }
}