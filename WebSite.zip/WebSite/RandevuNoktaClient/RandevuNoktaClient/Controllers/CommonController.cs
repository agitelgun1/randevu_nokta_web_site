﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Entity;
using Domain.ViewModel;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using RandevuNoktaClient.Features.Common;

namespace RandevuNoktaClient.Controllers
{
    public class CommonController : Controller
    {
        private readonly IMediator _mediatr;
        public CommonController(IMediator mediatr)
        {
            _mediatr = mediatr;
        }

        public async Task<IActionResult> GetCity(string q)
        {
            if(string.IsNullOrEmpty(q) == false && q.Length > 2)
            {
                var list = await _mediatr.Send(new CityAndDistrictSearch.Query
                {
                    query = q
                });

                return Ok(list.Result.CityList);
            }

            return Ok(new List<City>());
            
        }

        public async Task<IActionResult> GetDistirct(string q)
        {
            if (string.IsNullOrEmpty(q) == false && q.Length > 2)
            {
                var list = await _mediatr.Send(new CityAndDistrictSearch.Query
                {
                    query = q
                });

                return Ok(list.Result.DistrictList);
            }

            return Ok(new List<District>());
                
        }
    }
}   