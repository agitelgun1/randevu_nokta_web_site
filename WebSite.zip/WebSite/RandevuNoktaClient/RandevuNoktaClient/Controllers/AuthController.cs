﻿using System.Threading;
using Domain.ServiceRequest.Auth;
using Domain.ViewModel;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using RandevuNoktaClient.Features.Auth;
using System.Threading.Tasks;
using Domain.ServiceModel;

namespace RandevuNoktaClient.Controllers
{
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IMediator _mediatr;
        private readonly IConfiguration _configuration;

        public AuthController(IMediator mediatr, IConfiguration configuration)
        {
            _mediatr = mediatr;
            _configuration = configuration;
        }

        #region ViewMethods

        [HttpGet("login")]
        public IActionResult Login()
        {
            return View(new PageAlert());
        }

        [HttpGet("logout")]
        public IActionResult LogOut()
        {
            var cookieKey = _configuration.GetSection("Auth:CookieKey").Value;
            Response.Cookies.Delete(cookieKey);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet("register")]
        public IActionResult Register()
        {
            return View();
        }

        [HttpGet("forgotpassword")]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpGet("resetpassword")]
        public IActionResult ResetPassword()
        {
            return View();
        }

        #endregion

        #region JsonResult

        [HttpPost("register")]
        public async Task<JsonResult> Register([FromBody] RegisterRequest request)
        {
            var result = await _mediatr.Send(new Register.Query
            {
                register = request
            });


            return Json(result);
        }

        [HttpPost("login")]
        public async Task<JsonResult> Login([FromBody] LoginModel param)
        {
            var cookieKey = _configuration.GetSection("Auth:CookieKey").Value;
            Response.Cookies.Delete(cookieKey);

            var userResponse = await _mediatr.Send(new Login.Query
            {
                login = param
            });

            cookieKey = _configuration.GetSection("Auth:CookieKey").Value;

            if (userResponse != null && userResponse.IsSuccess)
            {
                Response.Cookies.Append(cookieKey, userResponse.Result.Token);
            }

            return Json(userResponse);
        }

        [HttpPost("forgotpassword")]
        public async Task<JsonResult> ForgotPassword([FromBody] ForgotPasswordRequest request)
        {
            var userResponse = await _mediatr.Send(new ForgotPassword.Query
            {
                Email = request.Email
            }, CancellationToken.None);

            return Json(userResponse);
        }
        
        [HttpGet("checkpasswordhash")]
        public async Task<JsonResult> CheckPasswordHash([FromQuery] string hash)
        {
            var userResponse = await _mediatr.Send(new CheckPasswordHash.Query
            {
                Hash = hash
            }, CancellationToken.None);

            return Json(userResponse);
        }
        
        [HttpPost("changeforgotpassword")]
        public async Task<JsonResult> ChangeForgotPassword([FromBody] ChangeForgotPasswordRequest request)
        {
            var userResponse =new BaseResponse<bool>();
            
            var checkPasswordHash = await _mediatr.Send(new ChangeForgotPassword.Query
            {
                ChangeForgotPasswordRequest = request
            }, CancellationToken.None);
            
            if (checkPasswordHash != null && checkPasswordHash.IsSuccess)
            {
                userResponse = await _mediatr.Send(new ChangeForgotPassword.Query
                {
                    ChangeForgotPasswordRequest = request
                }, CancellationToken.None);
                
            }
            return Json(userResponse);
        }
        #endregion
    }
}