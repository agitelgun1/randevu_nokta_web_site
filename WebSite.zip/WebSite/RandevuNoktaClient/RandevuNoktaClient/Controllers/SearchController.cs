using System.Threading.Tasks;
using Core.Services;
using Domain.ServiceModel;
using Microsoft.AspNetCore.Mvc;

namespace RandevuNoktaClient.Controllers
{
    public class SearchController : Controller
    {
        private readonly ISearchService _searchService;

        public SearchController(ISearchService searchService)
        {
            _searchService = searchService;
        }

        public async Task<IActionResult> AutoComplete(string q,string cityId,string districtId)
        {
            if (string.IsNullOrEmpty(q) == false && q.Length > 2)
            {
                var result = await _searchService.AutoComplete(q,cityId,districtId);
                return Ok(result);
            }

            return Ok(new AutocompleteResponse());
        }

        public async Task<IActionResult> DoctorSearch(string term, int cityId, int districtId, double lat, double lng)
        {
            if (string.IsNullOrEmpty(term) || term.Length <= 2) return Ok(false);

            var result = await _searchService.DoctorSearchByTerm(term, cityId, districtId, lat, lng);

            return Ok(result);
        }

        public async Task<IActionResult> ClinicSearch(string term, int cityId, int districtId, double lat, double lng, int pageIndex, int pageSize)
        {
            if (string.IsNullOrEmpty(term) || term.Length <= 2) return Ok(false);

            var result = await _searchService.ClinicSearchByTerm(term, cityId, districtId, lat, lng, pageIndex, pageSize);

            return Ok(result);
        }

        public async Task<IActionResult> ClinicSearchWithoutTerm(string term, int cityId, int districtId, double lat,
            double lng, int pageIndex, int pageSize)
        {
            var result =
                await _searchService.ClinicSearchByTerm(term, cityId, districtId, lat, lng, pageIndex, pageSize);

            return Ok(result);
        }
    }
}