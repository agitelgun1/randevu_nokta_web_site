﻿using Microsoft.AspNetCore.Mvc;

namespace RandevuNoktaClient.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        
        [HttpGet("enduseraggrement")]
        public IActionResult EndUserAgreement()
        {
            return View();
        }
        [HttpGet("confidentialityagreement")]
        public IActionResult ConfidentialityAgreement()
        {
            return View();
        }
        
        [HttpGet("cookiepolicy")]
        public IActionResult CookiePolicy()
        {
            return View();
        }
    }
}
