using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Services;
using Domain.DTO;
using Domain.Entity;
using Domain.ServiceModel;
using Domain.ServiceRequest.Doctor;
using Domain.ViewModel;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using RandevuNoktaClient.Features.Comment;

namespace RandevuNoktaClient.Controllers
{
    [Route("doctor")]
    public class DoctorController : Controller
    {
        private readonly IMediator _mediatr;
        private readonly IDoctorService _doctorService;

        public DoctorController(IMediator mediatr, IDoctorService doctorService)
        {
            _mediatr = mediatr;
            _doctorService = doctorService;
        }

        [HttpGet("doctordetail")]
        public IActionResult DoctorDetail()
        {
            return View();
        }
        
        [HttpGet("adddoctorcomment")]
        public IActionResult AddDoctorComment(string name, string surName)
        {
            var commentModel = new AddDoctorCommentModel {Name = name, Surname = surName};
            return View(commentModel);
        }

        [HttpPost("adddoctorcomment")]
        public async Task<JsonResult> AddDoctorComment([FromBody] CreateDoctorCommentRequest request)
        {
            var result = await _mediatr.Send(new AddDoctorComment.Query
            {
                DoctorCommentRequest = request
            });


            return Json(result);
        }

        [HttpGet("list")]
        public async Task<IActionResult> List()
        {
            return View();
        }
        
        [HttpPost("loadmore")]
        public async Task<IActionResult> _DoctorComments(string doctorId,int size)
        {
            //todo : doctor id yi ekle
            
            var comments = await _doctorService.LoadMoreComment("13", size);

            return PartialView("_DoctorComments", comments);
        }
        
        [HttpGet("DoctorDetailInfo")]
        public async Task<JsonResult> DoctorDetailInfo(int doctorId)
        {
            var response = new BaseResponse<DoctorAllInfoDTO>();
            
            var doctorInfo = _doctorService.GetDoctorGeneralInfo(doctorId);
            var clinicList = _doctorService.GetClinicListByDoctorId(doctorId);
            var branchList = _doctorService.GetBranchListByDoctorId(doctorId);
            var professionList = _doctorService.GetProfessionListByDoctorId(doctorId);
            var experienceList = _doctorService.GetExperienceListByDoctorId(doctorId);
            var insuranceList = _doctorService.GetInsuranceListByDoctorId(doctorId);
            var treatmentList = _doctorService.GetTreatmentListByDoctorId(doctorId);
            var languageList = _doctorService.GetLanguageListByDoctorId(doctorId);
            var commentList = _doctorService.GetDoctorCommentsListByDoctorId(doctorId);
            var paymentMethodsList = _doctorService.GetMethodListByDoctorId(doctorId);
            
            var taskList = new List<Task>();
            taskList.Add(doctorInfo);
            taskList.Add(clinicList);
            taskList.Add(branchList);
            taskList.Add(professionList);
            taskList.Add(experienceList);
            taskList.Add(insuranceList);
            taskList.Add(treatmentList);
            taskList.Add(languageList);
            taskList.Add(commentList);
            taskList.Add(paymentMethodsList);

            var task = Task.WhenAll(taskList.ToArray());

            await task;

            if (task.Status == TaskStatus.RanToCompletion)
            {
                var doctorAllInfo = new DoctorAllInfoDTO
                {
                    BranchList = branchList.Result?.Result,
                    DoctorGeneralInfo = doctorInfo.Result?.Result,
                    ClinicList = clinicList.Result?.Result,
                    ProfessionList = professionList.Result?.Result,
                    ExperienceList = experienceList.Result?.Result,
                    InsuranceList = insuranceList.Result?.Result,
                    TreatmentList = treatmentList.Result?.Result,
                    LanguageList = languageList.Result?.Result,
                    DoctorComments = commentList.Result?.Result?.Comments ?? new List<UsersComment>(),
                    ReviewerCount = commentList.Result?.Result?.Comments?.Count() ?? 0,
                    Score = (commentList.Result?.Result?.Comments?.Count() ?? 0) == 0 ? 0 : (double) commentList.Result?.Result?.Comments?.Average(x => x.Score),
                    CommentPercentageByScore = commentList.Result?.Result?.CommentPercentageByScore?.OrderByDescending(x => x.Key).ToDictionary(x => x.Key, x => x.Value) ?? new Dictionary<int, double>(),
                    PaymentMethodsList = paymentMethodsList.Result?.Result ?? new List<PaymentMethods>()
                };
                
                response.Result = doctorAllInfo;
                response.IsSuccess = true;
            }
            else
            {
                response.IsSuccess = false;
                response.ErrorDescription = "Bir hata oluştu lütfen sonra tekrar deneyiniz.";
            }

            return Json(response);
        }
        
    }
}