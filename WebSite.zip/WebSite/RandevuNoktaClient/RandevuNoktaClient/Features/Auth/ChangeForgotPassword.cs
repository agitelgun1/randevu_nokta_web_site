using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.Extensions;
using Domain.ServiceModel;
using Domain.ServiceRequest.Auth;
using MediatR;

namespace RandevuNoktaClient.Features.Auth
{
    public class ChangeForgotPassword
    {
        public class Query : IRequest<BaseResponse<bool>>
        {
            public ChangeForgotPasswordRequest ChangeForgotPasswordRequest { get; set; }
        }
        public class ChangeForgotPasswordHandler : IRequestHandler<Query, BaseResponse<bool>>
        {
            
            private readonly AuthServiceClient _authServiceClient;

            public ChangeForgotPasswordHandler(AuthServiceClient authServiceClient)
            {
                _authServiceClient = authServiceClient;
            }

            public async Task<BaseResponse<bool>> Handle(Query request,
                CancellationToken cancellationToken)
            {
                var user = await _authServiceClient.PostObject<BaseResponse<bool>>("api/password/changeforgotpassword",
                    request.ChangeForgotPasswordRequest);

                return user;
            }
        }
    }
}