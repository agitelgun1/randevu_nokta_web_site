﻿using System.Collections.Generic;
using Core.Extensions;
using Domain.ServiceModel;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace RandevuNoktaClient.Features.Auth
{
    public class ForgotPassword
    {
        public class Query : IRequest<BaseResponse<UserResponse>>
        {
            public string Email { get; set; }
        }

        public class ForgotPasswordHandler : IRequestHandler<Query, BaseResponse<UserResponse>>
        {
            private readonly MailServiceClient _mailClient;
            private readonly UserServiceClient _userServiceClient;

            public ForgotPasswordHandler(MailServiceClient mailClient, UserServiceClient userServiceClient)
            {
                _userServiceClient = userServiceClient;
                _mailClient = mailClient;
            }

            public async Task<BaseResponse<UserResponse>> Handle(Query request,
                CancellationToken cancellationToken)
            {
                var param = new Dictionary<string, string>
                {
                    {"email", request.Email}
                };

                var user = await _userServiceClient.GetObject<BaseResponse<UserResponse>>("api/user/getuserbymail",
                    param);

                if (user.Result != null && !string.IsNullOrEmpty(user.Result.Email)) return user;
                
                var mailParam = new Dictionary<string, string>
                {
                    {"emailAddress", request.Email}
                };
                _mailClient.GetObject<BaseResponse<bool>>("api/sendforgotpasswordmail",mailParam);

                return user;
            }
        }
    }
}