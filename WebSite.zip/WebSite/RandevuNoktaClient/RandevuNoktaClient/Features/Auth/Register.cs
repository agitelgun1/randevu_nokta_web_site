﻿using Core.Extensions;
using Domain.ServiceModel;
using Domain.ServiceRequest.Auth;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Domain.AppModel;

namespace RandevuNoktaClient.Features.Auth
{
    public class Register
    {
        public class Query : IRequest<BaseResponse<bool>>
        {
            public RegisterRequest register { get; set; }

        }
        
        public class RegisterHandler : IRequestHandler<Query, BaseResponse<bool>>
        {
            private readonly AuthServiceClient _client;
            private readonly UserServiceClient _userServiceClient;

            public RegisterHandler(AuthServiceClient client, UserServiceClient userServiceClient)
            {
                _client = client;
                _userServiceClient = userServiceClient;
            }

            public async Task<BaseResponse<bool>> Handle(Query request, CancellationToken cancellationToken)
            {
                 var data = new BaseResponse<bool>()
                 {
                     IsSuccess = false,
                 };
                     
                var param = new Dictionary<string, string>
                {
                    {"email", request.register.Email}
                };

                var user = await _userServiceClient.GetObject<BaseResponse<UserResponse>>("api/user/getuserbymail",
                    param);

                if (user.Result != null && !string.IsNullOrEmpty(user.Result.Email))
                {
                    data.ErrorDescription = "Ayni email adresinden kayit bulunmaktadir!";
                    return data;
                }

                request.register.Roles = new List<string> {Role.User};
                data = await _client.PostObject<BaseResponse<bool>>("api/auth/register", request.register);

                return data;
            }
        }
    }
}
