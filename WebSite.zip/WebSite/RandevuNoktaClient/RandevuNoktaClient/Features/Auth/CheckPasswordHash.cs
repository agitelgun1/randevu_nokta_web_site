using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.Extensions;
using Domain.ServiceModel;
using MediatR;

namespace RandevuNoktaClient.Features.Auth
{
    public class CheckPasswordHash
    {
        public class Query : IRequest<BaseResponse<bool>>
        {
            public string Hash { get; set; }
        }
        
     
        public class CheckPasswordHashHandler : IRequestHandler<Query, BaseResponse<bool>>
        {
            
            private readonly MailServiceClient _mailServiceClient;

            public CheckPasswordHashHandler(MailServiceClient mailServiceClient)
            {
                _mailServiceClient = mailServiceClient;
            }

            public async Task<BaseResponse<bool>> Handle(Query request,
                CancellationToken cancellationToken)
            {
                var param = new Dictionary<string, string>
                {
                    {"hash", request.Hash}
                };

                var user = await _mailServiceClient.GetObject<BaseResponse<bool>>("api/checkforgotpasswordhash",
                    param);

                return user;
            }
        }
    }
}