﻿using Core.Extensions;
using Domain.ServiceModel;
using Domain.ViewModel;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RandevuNoktaClient.Features.Auth
{
    public class Login
    {
        public class Query : IRequest<BaseResponse<LoginResponse>>
        {
            public LoginModel login { get; set; }

        }
        

        public class LoginHandler : IRequestHandler<Query, BaseResponse<LoginResponse>>
        {
            private readonly AuthServiceClient _client;

            public LoginHandler(AuthServiceClient client)
            {
                _client = client;
            }

            public async Task<BaseResponse<LoginResponse>> Handle(Query request, CancellationToken cancellationToken)
            {
                var data = await _client.PostObject<BaseResponse<LoginResponse>>("api/auth/login", request.login);
                
                return data;
            }
        }
    }
}
