﻿using Core.Extensions;
using Domain.ServiceModel;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RandevuNoktaClient.Features.Common
{
    public class CityAndDistrictSearch
    {
        public class Query : IRequest<BaseResponse<CityAndDistrictSearchResponse>>
        {
            public string query { get; set; }

        }


        public class CityAndDistrictSearchHandler : IRequestHandler<Query, BaseResponse<CityAndDistrictSearchResponse>>
        {
            private readonly CommonServiceClient _client;

            public CityAndDistrictSearchHandler(CommonServiceClient client)
            {
                _client = client;
            }

            public async Task<BaseResponse<CityAndDistrictSearchResponse>> Handle(Query request, CancellationToken cancellationToken)
            {
                var param = new Dictionary<string, string>();
                param.Add("searchText", request.query);

                var data = await _client.GetObject<BaseResponse<CityAndDistrictSearchResponse>>("api/search", param);

                return data;
            }
        }
    }
}
