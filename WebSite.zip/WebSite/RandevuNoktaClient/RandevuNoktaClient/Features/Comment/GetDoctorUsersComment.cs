using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.Extensions;
using Domain.ServiceModel;
using MediatR;

namespace RandevuNoktaClient.Features.Comment
{
    public class GetDoctorUsersComment
    {
        public class Query : IRequest<BaseResponse<DoctorUsersCommentResponse>>
        {
            public string id { get; set; }
        }

        public class GetDoctorUsersCommentHandler : IRequestHandler<Query, BaseResponse<DoctorUsersCommentResponse>>
        {
            private readonly CommonServiceClient _client;

            public GetDoctorUsersCommentHandler(CommonServiceClient client)
            {
                _client = client;
            }

            public async Task<BaseResponse<DoctorUsersCommentResponse>> Handle(Query request,
                CancellationToken cancellationToken)
            {
                var param = new Dictionary<string, string> {{"doctorId", request.id}};

                var data =
                    await _client.GetObject<BaseResponse<DoctorUsersCommentResponse>>("api/getdoctoruserscomment",
                        param);

                return data;
            }
        }
    }
}