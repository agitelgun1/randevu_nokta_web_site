using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Core.Extensions;
using Domain.AppModel;
using Domain.ServiceModel;
using Domain.ServiceRequest.Auth;
using Domain.ServiceRequest.Doctor;
using MediatR;

namespace RandevuNoktaClient.Features.Comment
{
    public class AddDoctorComment
    {
        public class Query : IRequest<BaseResponse<bool>>
        {
            public CreateDoctorCommentRequest DoctorCommentRequest { get; set; }

        }
        
        public class AddDoctorCommentHandler : IRequestHandler<Query, BaseResponse<bool>>
        {
            private readonly CommonServiceClient _client;

            public AddDoctorCommentHandler(CommonServiceClient client)
            {
                _client = client;
            }

            public async Task<BaseResponse<bool>> Handle(Query request, CancellationToken cancellationToken)
            {
                request.DoctorCommentRequest.CreateDate=DateTime.Now;
                request.DoctorCommentRequest.UpdatedDate=DateTime.Now;
                var data = await _client.PostObject<BaseResponse<bool>>("api/createcomment", request.DoctorCommentRequest);

                return data;
            }
        }
    }
}