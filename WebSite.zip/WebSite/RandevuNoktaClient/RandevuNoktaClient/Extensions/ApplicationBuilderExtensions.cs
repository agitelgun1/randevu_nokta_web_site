using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using RandevuNoktaClient.Middleware;

namespace RandevuNoktaClient.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static void UseErrorMiddleware(this IApplicationBuilder builder)
        {
            builder.UseMiddleware<ErrorMiddleware>();
        }
        
        public static void UseExceptionPageEnv(this IApplicationBuilder builder,IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                builder.UseDeveloperExceptionPage();
            }
            else
            {
                builder.UseExceptionHandler("/Home/Error");
            }
        }
        public static void UseMvcBuilder(this IApplicationBuilder builder)
        {
            builder.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}