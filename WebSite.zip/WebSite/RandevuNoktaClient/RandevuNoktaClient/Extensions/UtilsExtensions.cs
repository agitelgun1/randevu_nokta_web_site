using System.Collections.Generic;
using System.Linq;

namespace RandevuNoktaClient.Extensions
{
    public static class UtilsExtensions
    {
        public static bool IsAny<T>(this IEnumerable<T> data) {
            return data != null && data.Any();
        }
    }
}