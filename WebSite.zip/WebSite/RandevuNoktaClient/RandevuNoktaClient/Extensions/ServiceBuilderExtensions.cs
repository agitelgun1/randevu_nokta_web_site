using System;
using System.IO.Compression;
using System.Security.Claims;
using Core.Configuration;
using Core.Extensions;
using Core.Helper;
using Core.Services;
using Core.Services.ServiceBusiness;
using Core.Services.ServiceInterface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RandevuNoktaClient.Authentication;

namespace RandevuNoktaClient.Extensions
{
    public static class ServiceBuilderExtensions
    {
        public static void ConfigureSingletonCollections(this IServiceCollection services)
        {
            services.AddSingleton<ISearchService, SearchService>();
            services.AddSingleton<IHospitalService, HospitalService>();
            services.AddSingleton<IDoctorService, DoctorService>();
            services.AddSingleton<IConnectionHelper, ConnectionHelper>();
            services.AddSingleton<IErrorService, ErrorService>();
            services.AddSingleton<IAppointmentService, AppointmentService>();
            services.AddSingleton<IUserService, UserService>();
        }
        
        public static void ConfigureHttpClientCollections(this IServiceCollection services,IConfiguration Configuration)
        {
          
            var authConfig = Configuration.GetSection("AuthServiceConfig").Get<ServiceConfig>();
            var commonConfig = Configuration.GetSection("CommonServiceConfig").Get<ServiceConfig>();
            var mailConfig = Configuration.GetSection("MailServiceConfig").Get<ServiceConfig>();
            var userServiceConfig = Configuration.GetSection("UserServiceConfig").Get<ServiceConfig>();

            services.AddHttpClient<AuthServiceClient>(client => { client.BaseAddress = new Uri(authConfig.Url); });
            services.AddHttpClient<CommonServiceClient>(client => { client.BaseAddress = new Uri(commonConfig.Url); });
            services.AddHttpClient<MailServiceClient>(client => { client.BaseAddress = new Uri(mailConfig.Url); });
            services.AddHttpClient<UserServiceClient>(
                client => { client.BaseAddress = new Uri(userServiceConfig.Url); });
        }
        
        public static void ConfigureCompressionCollection(this IServiceCollection services)
        {
            services.AddResponseCompression(opt => { opt.Providers.Add<GzipCompressionProvider>(); });
            services.Configure<GzipCompressionProviderOptions>(options => options.Level =
                CompressionLevel.Fastest);
        }
        
        public static void ConfigureCollection(this IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
        }
        
        public static void ConfigureMvcCoreCollection(this IServiceCollection services)
        {
            services.AddMvcCore()
                .AddAuthorization(options =>
                {
                    options.AddPolicy("UserPolicy", policy => policy.RequireClaim(ClaimTypes.Role));
                });
            services.AddAuthentication(options =>
                {
                    options.DefaultScheme = AuthOptions.DefaultScheme;
                    options.DefaultAuthenticateScheme = AuthOptions.DefaultScheme;
                    options.DefaultChallengeScheme = AuthOptions.DefaultScheme;
                })
                .AddAuth(options => { });
        }
    }
}