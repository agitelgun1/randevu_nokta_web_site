﻿$.ajaxSetup({
    error: function (x, status, error) {
        
        if (x.status === 403 || x.status === 401) {
            window.location.href = "/Auth/Login";
        }
        else {
            //console.log("An error occurred: " + status + "nError: " + error);
        }
    },
    beforeSend: function () {

        if (isSpecialUrl(this.url) === false)
        Notiflix.Loading.Circle('Lütfen bekleyiniz...');
    },
    complete: function () {

        if (isSpecialUrl(this.url) === false)
        Notiflix.Loading.Remove();
    },
    dataFilter: function (data, type) {

        if (isSpecialUrl(this.url) === false) {
            
            var response = JSON.parse(data);

            if (response !== undefined && response !== null && (response.isSuccess === true || response.success === true)) {

                return JSON.stringify(response.result);
            }
            
            if (response.userMesssage !== undefined && response.userMesssage !== null &&response.userMesssage !== '' && response.userMesssage !== '') {

                //toastr.error(response.userMesssage, response.userMessageTitle);
                // Notiflix.Notify.Failure(response.userMessageTitle);
                // Notiflix.Report.Failure(response.userMessageTitle, response.userMesssage,'Kapat');
                toastr.warning(response.userMesssage, 'Dikkat!');
            }
        }
        else {

            return data;
        }

        
    }
});


function isSpecialUrl(url) {

    return url.includes('common/GetCity?q')
        || url.includes('common/GetDistirct?q')
        || url.includes('Search/AutoComplete?q')
        || url.includes('Templates/');
        //|| url.includes('Search/DoctorSearch');

    
}