Handlebars.registerHelper('pagination', function(currentPage, totalPage, size, options) {
    var startPage, endPage, context;

    if (arguments.length === 3) {
        options = size;
        size = 5;
    }

    startPage = currentPage - Math.floor(size / 2);
    endPage = currentPage + Math.floor(size / 2);

    if (startPage <= 0) {
        endPage -= (startPage - 1);
        startPage = 1;
    }

    if (endPage > totalPage) {
        endPage = totalPage;
        if (endPage - size + 1 > 0) {
            startPage = endPage - size + 1;
        } else {
            startPage = 1;
        }
    }

    context = {
        startFromFirstPage: false,
        pages: [],
        endAtLastPage: false
    };
    if (startPage === 1) {
        context.startFromFirstPage = true;
    }
    for (var i = startPage; i <= endPage; i++) {
        context.pages.push({
            page: i,
            isCurrent: i === currentPage
        });
    }
    if (endPage === totalPage) {
        context.endAtLastPage = true;
    }

    return options.fn(context);
});

Handlebars.registerHelper('log', function (items) {
    console.log('register helper log ---: ', items);
});

Handlebars.registerHelper('list', function (items, options) {
    var out = "";
    if (items !== null && items.length > 0) {
        for (var i = 0, l = items.length; i < l; i++) {
            out = out + options.fn(items[i]);
        }
    }
    return out;
});

Handlebars.registerHelper('times', function (n, options) {

    var val = parseInt(n, 10);

    var accum = '';
    for (var i = 0; i < val; ++i)
        accum += options.fn(i);
    return accum;
});

Handlebars.registerHelper('iconStar', function (value, options) {

    var val = parseInt(value, 10);

    var accum = '';
    for (var i = 0; i < 5 - val; ++i)
        accum += options.fn(i);
    return accum;
});

Handlebars.registerHelper('numberFormat', function (deger, options) {

    var dl = options.hash['decimalLength'] || 2;
    var ts = options.hash['thousandsSep'] || ',';
    var ds = options.hash['decimalSep'] || '.';

    var value = parseFloat(deger);

    var re = '\\d(?=(\\d{3})+' + (dl > 0 ? '\\D' : '$') + ')';

    // Formats the number with the decimals
    var num = value.toFixed(Math.max(0, ~~dl));

    // Returns the formatted number
    return (ds ? num.replace('.', ds) : num).replace(new RegExp(re, 'g'), '$&' + ts);
});

Handlebars.registerHelper('concat', function (strArr) {
    return strArr.join(" - ");
});

Handlebars.registerHelper('each_reverse', function (context, options) {
    var fn = options.fn, inverse = options.inverse;
    var length = 0, ret = "", data;

    if (Handlebars.Utils.isFunction(context)) {
        context = context.call(this);
    }

    if (options.data) {
        data = Handlebars.createFrame(options.data);
    }

    if (context && typeof context === 'object') {
        if (Handlebars.Utils.isArray(context)) {
            length = context.length;
            for (var j = context.length - 1; j >= 0; j--) {//no i18n
                if (data) {
                    data.index = j;
                    data.first = (j === 0);
                    data.last = (j === (context.length - 1));
                }
                ret = ret + fn(context[j], {data: data});
            }
        } else {
            var keys = Object.keys(context);
            length = keys.length;
            for (j = length; j >= 0; j--) {
                var key = keys[j - 1];
                if (context.hasOwnProperty(key)) {
                    if (data) {
                        data.key = key;
                        data.value = context[key];
                        data.index = j;
                        data.first = (j === 0);
                    }
                    ret += fn(context[key], {data: data});
                }
            }
        }
    }

    if (length === 0) {
        ret = inverse(this);
    }

    return ret;
});

Handlebars.registerHelper('trimString', function (passedString) {

    var len = passedString.length;
    var theString = '';
    if (len > 50) {
        theString = passedString.substring(0, 50);
    } else {
        theString = passedString.substring(0, len);
    }
    return new Handlebars.SafeString(theString)
});

Handlebars.registerHelper('dateFormat', function (context, block) {
    if (window.moment) {
        var f = block.hash.format || "DD.MM.YYYY HH:mm";
        return moment(Date(context)).format(f);
    } else {
        return context;   //  moment plugin not available. return data as is.
    }
});