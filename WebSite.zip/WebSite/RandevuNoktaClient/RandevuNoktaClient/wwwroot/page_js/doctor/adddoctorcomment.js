function PageInit() {

}


function addComment() {

    var title = $('#txtTitle').val();
    var description = $('#txtDescription').val();
    var contracts = $("#contractsCheckBox").is(':checked');
    var score = getScore();

    if (score < 1 || score === "" || score === undefined) {
        document.getElementById("msgScores").innerHTML = "<br/>Lütfen puanlama yapınız!";
        document.getElementById("msgScores").style.color = "red";
        return;
    }

    if (title === "" || title === undefined) {
        document.getElementById("msgTitle").innerHTML = "<br/>Lütfen başlık giriniz!";
        document.getElementById("msgTitle").style.color = "red";
        return;
    }

    if (description === "" || description === undefined) {
        document.getElementById("msgDescription").innerHTML = "<br/>Lütfen yorumunuzu yazınız!";
        document.getElementById("msgDescription").style.color = "red";
        return;
    }

    if (!contracts) {
        document.getElementById("msgContracts").innerHTML = "<br/>Lütfen Kullanım sözleşmesini ve Gizlilik politikasini onaylayiniz!";
        document.getElementById("msgContracts").style.color = "red";
        return;
    }

    //Multiple click kapatilmasi icin bu konuldu!
    document.getElementById("btnComment").style.pointerEvents = "none";

    var registerObj = {};

    registerObj.Title = title;
    registerObj.Description = description;
    registerObj.Score = score;
    //TODO : asagidaki datalari doldur!
    registerObj.user_name = 'dummy user';
    registerObj.user_image_url = 'http://via.placeholder.com/150x150.jpg';
    registerObj.doctor_id = 13;
    registerObj.user_id = 18;
    registerObj.clinic_id = 3;
    $.ajax({
        type: "POST",
        url: "/doctor/adddoctorcomment",
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        data: JSON.stringify(registerObj),
        success: function (result) {

            if (result !== undefined && result !== null && result.token !== '') {

                Notiflix.Notify.Success('Yorumunuz başarılı bir şekilde oluşturuldu.');
                Notiflix.Notify.Success('Giriş sayfasına yönlendiriliyorsunuz...');

                document.getElementById("btnComment").style.pointerEvents = "auto";
                setInterval(function () {

                    window.location.href = '/home/index';
                }, 1300);
            }
        },
        error: function (result) {
            document.getElementById("btnComment").style.pointerEvents = "auto";

            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
}

function validateTitleText(text) {
    if (text.length !== 0) {
        document.getElementById("msgTitle").innerHTML = "";
    }
}

function validateDescriptionText(text) {
    if (text.length !== 0) {
        document.getElementById("msgDescription").innerHTML = "";
    }
}

function checkContracts() {

    var contracts = $("#contractsCheckBox").is(':checked');

    if (contracts) {
        document.getElementById("msgContracts").innerHTML = "";
    }
}

function getScore() {

    if ($("#1_star").prop("checked")) {
        return 1;
    }
    if ($("#2_star").prop("checked")) {
        return 2;
    }
    if ($("#3_star").prop("checked")) {
        return 3;
    }
    if ($("#4_star").prop("checked")) {
        return 4;
    }
    if ($("#5_star").prop("checked")) {
        return 5;
    }
}

function isEmpty(str) {
    return !str.replace(/\s+/, '').length;
}

document.getElementById("txtTitle").addEventListener("input", function () {
    if (isEmpty(this.value)) {
    }
});

