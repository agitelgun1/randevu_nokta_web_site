﻿function PageInit() {

    initPartials();
}


function initPartials() {
}

function loadMore() {
    var loadCount = 1;
    var loadObj = {};
    loadObj.size = loadCount * 5;

    $.ajax({
        type: "POST",
        url: "/doctor/loadmore",
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        data: JSON.stringify(loadObj),
        cache: false,
        success: function (result) {

            if (result !== undefined && result !== null) {

                $('#doctor_comment_partial_view').html(result);
            }
        },
        error: function (result) {
            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
    loadCount = loadCount + 1;
}