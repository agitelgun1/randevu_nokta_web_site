function PageInit() {

    initPartials();
    
}


function initPartials() {

    doctorListInit();
    searchBarPanelInit();
}