var urlParams = new URLSearchParams(window.location.search);
var doctor_id = urlParams.get('id');
var selectedClinic;

function PageInit() {

    loadComponents();
    getDoctorGeneralInfo();
}


function loadComponents() {
    
}

function getDoctorGeneralInfo() {

    $.ajax({
        type: "GET",
        url: "/doctor/DoctorDetailInfo?doctorId=" + doctor_id,
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        cache: false,
        success: function (result) {
            
            if(result !== undefined && result !== null)
            {

                if(result.clinicList !== undefined && result.clinicList !== null && result.clinicList.length == 1)
                {
                    selectedClinic = result.clinicList[0].id;
                }
                
                doctorProfileRender(result);
                doctorProfessionRender(result);
                doctorClinicListRender(result);
                doctorBranchListRender(result);
                doctorGraduateRender(result);
                doctorExperienceListRender(result);
                doctorTreatmentListRender(result);
                doctorLanguageListRender(result);
                doctorInsuranceListRender(result);
                doctorCommentListRender(result);
                doctorPaymentMethodsListRender(result);
                doctorCalendarRender();
            }
        }
    });
}

function doctorProfileRender(data) {

    var source = document.getElementById("doctor-profile-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#doctor_profile_box').html(template(data));
}

function doctorProfessionRender(data) {

    var source = document.getElementById("doctor-profession-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#professionList').html(template(data));
}

function doctorClinicListRender(data) {

    var source = document.getElementById("doctor-clinic-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#clinic_list').html(template(data));

    if(data.clinicList !== undefined && data.clinicList !== null && data.clinicList.length == 1)
    {
        $('#clinic_' + data.clinicList[0].id).prop('checked', true);
    }
}

function doctorBranchListRender(data) {

    var source = document.getElementById("doctor-branch-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#branchList').html(template(data));
}

function doctorGraduateRender(data) {

    var source = document.getElementById("doctor-university-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('.list_edu').html(template(data));
}

function doctorExperienceListRender(data) {

    var source = document.getElementById("doctor-experience-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#experienceList').html(template(data));
}

function doctorLanguageListRender(data) {

    var source = document.getElementById("doctor-language-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#languageList').html(template(data));
}

function doctorInsuranceListRender(data) {

    var source = document.getElementById("doctor-insurance-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#insuranceList').html(template(data));
}

function doctorTreatmentListRender(data) {

    var source = document.getElementById("doctor-treatment-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#treatmentList').html(template(data));
}

function doctorCommentListRender(data) {
    var source = document.getElementById("doctor-comment-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#doctor_comments_list_info_box').html(template(data));
}

function doctorPaymentMethodsListRender(data) {
    var source = document.getElementById("doctor-payment-method-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#paymentMethodList').html(template(data));
}

