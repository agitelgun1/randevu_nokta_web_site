﻿function PageInit() {

    initPartials();
}


function initPartials() {

    searchPanelInit();
}