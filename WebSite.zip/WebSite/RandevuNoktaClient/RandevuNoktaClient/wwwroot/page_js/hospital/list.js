function PageInit() {

    initPartials();
}


function initPartials() {

    clinicListInit();
}