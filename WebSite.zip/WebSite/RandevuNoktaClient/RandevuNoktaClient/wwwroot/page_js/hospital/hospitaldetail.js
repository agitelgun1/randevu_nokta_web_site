var urlParams = new URLSearchParams(window.location.search);
var clinicId = urlParams.get('clinicId');

function PageInit() {

    loadComponents();
    getHospitalGeneralInfo(clinicId);
}


function loadComponents() {

}
function initMap(locations) {
    var map = L.map('map_listing').setView([locations[0].x,locations[0].y], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    $.each(locations, function (i, val) {
        L.marker([val.x, val.y]).addTo(map);
    });

}
function getHospitalGeneralInfo(clinicId) {
    $.ajax({
        type: "GET",
        url: "/hospital/HospitalDetailInfo?clinicId=" + clinicId,
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        cache: false,
        success: function (result) {
            if (result !== undefined && result !== null) {

                hospitalProfileRender(result);
                hospitalGeneralInfoRender(result);
                hospitalDoctorListRender(result);
                hospitalCommentListRender(result);

            }
        }
    });
}

function hospitalProfileRender(data) {

    var source = document.getElementById("hospital-profile-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#hospital_profile_box').html(template(data));
}

function hospitalGeneralInfoRender(data) {

    var source = document.getElementById("hospital-general-info-template").innerHTML;
    var template = Handlebars.compile(source);

    var locations = [];

    locations.push({x: parseFloat(data.clinicInfo.latitude), y: parseFloat(data.clinicInfo.longitude)});
   

    initMap(locations);

    $('#hospital_general_info_box').html(template(data));
}

function hospitalDoctorListRender(data) {

    var source = document.getElementById("hospital-doctor-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#hospital_doctor_list_info_box').html(template(data));
}


function hospitalCommentListRender(data) {
    var source = document.getElementById("hospital-comment-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#hospital_comments_list_info_box').html(template(data));
}

function doctorClick(id) {

    window.location.href = '/doctor/doctorDetail?id=' + id;
}

