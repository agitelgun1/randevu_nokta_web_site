﻿function searchPanelInit() {

    initLocations();
    initAutoComplete();
    defaultEnterEvents();
}

function defaultEnterEvents() {

    var input = document.getElementsByClassName("searchList");

    input[1].addEventListener("keyup", function (event) {
        // Number 13 is the "Enter" key on the keyboard
        if (event.keyCode === 13) {

            btnClinicSearchInputClick();
        }
    });
}

function initLocations() {

    $('.distirctList').on('typeahead:selected', function (evt, item) {
        
        if (typeof item.name !== "undefined") {
            localStorage.setItem('city_district_text', item.name);
        }
        if (typeof item.plateCode !== "undefined") {
           localStorage.setItem('cityId', item.plateCode);
        }

        if (typeof item.cityId !=="undefined") {
            localStorage.setItem('cityId', item.cityId);
        }
        if (typeof item.id !== "undefined") {
            localStorage.setItem('districtId', item.id);
        }
    });

    let distirctSource = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        //prefetch: 'common/GetDistirct',
        remote: {
            url: 'common/GetDistirct?q=%QUERY',
            wildcard: '%QUERY'
        }
    });
    
    let citySource = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'common/GetCity?q=%QUERY',
            wildcard: '%QUERY'
        }
    });
    
    $(".distirctList").val(localStorage.getItem("city_district_text")).focus().trigger('keyup');

    $('.distirctList').typeahead({
            highlight: true,
        },
        {
            name: 'CityList',
            display: 'name',
            source: citySource,
            limit: 7 ,
            templates: {
                header: '<div class="suggest-district-menu">İller</div>',
                suggestion: Handlebars.compile('<div>{{name}}</div>')
            }
        },
        {
            name: 'DistrictList',
            display: 'name',
            source: distirctSource,
            limit: 7,
            templates: {
                header: '<div class="suggest-district-menu">İlçeler</div>',
                suggestion: Handlebars.compile('<div>{{name}},  ({{cityName}})</div>')
            }
        });
}

function btnClinicSearchInputClick() {

    var term = $('.searchList.tt-input').val();
    if (term === null || term === "") {
        window.location.href = 'hospital/list?term=' + term;
    }
    else{
        window.location.href = 'doctor/list?term=' + term;
    }
}


function btnClinicSearchClick(term) {

    window.location.href = 'doctor/list?term=' + term;
}

function searchInputOnFocus() {

    var district_text = $('.distirctList.tt-input').val();

    if (district_text === undefined || district_text === null || district_text === '') {
        Notiflix.Notify.Failure("Lütfen bir konum seçiniz!!!");
        $(".distirctList.tt-input").focus();
        return;
    }
}

function initAutoComplete() {

    let cityId = localStorage.getItem("cityId");
    let districtId = localStorage.getItem("districtId");

    //#### SearchFields Init #######
    var autocompleteDoctor = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        dupDetector: function (a, b) {
            return a.id_str === b.id_str;
        },
        remote: {
            url: 'Search/AutoComplete?q=%QUERY&cityId=' + cityId + '&districtId=' + districtId,
            wildcard: '%QUERY',
            transform: function (d) {
                return d.doctors;
            }
        }
    });

    function autocompleteDoctorDefaults(q, sync, async) {

        if (q === '') {
            autocompleteDoctor.search('dahiliye', sync, async)
        } else {
            autocompleteDoctor.search(q, sync, async);
        }
    }

    var autocompleteBranch = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        limit: 100,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY&cityId='+ cityId + '&districtId=' + districtId,
            wildcard: '%QUERY',
            transform: function (d) {
                return d.branches;
            }
        }
    });

    function autocompleteBranchDefaults(q, sync, async) {
        if (q === '') {
            autocompleteBranch.search('dahiliye', sync, async);
        } else {
            autocompleteBranch.search(q, sync, async);
        }
    }

    var autocompleteDisease = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY&cityId='+ cityId + '&districtId=' + districtId,
            wildcard: '%QUERY',
            transform: function (d) {

                return d.diseases;
            }
        }
    });

    function autocompleteDiseaseDefaults(q, sync, async) {
        if (q === '') {
            autocompleteDisease.search('dahiliye', sync, async);
        } else {
            autocompleteDisease.search(q, sync, async);
        }
    }

    var autocompleteTreatment = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY&cityId='+ cityId + '&districtId=' + districtId,
            wildcard: '%QUERY',
            transform: function (d) {

                return d.treatments;
            }
        }
    });

    function autocompleteTreatmentDefaults(q, sync, async) {
        if (q === '') {
            autocompleteTreatment.search('dahiliye', sync, async);
        } else {
            autocompleteTreatment.search(q, sync, async);
        }
    }

    var autocompleteClinic = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY&cityId='+ cityId + '&districtId=' + districtId,
            wildcard: '%QUERY',
            transform: function (d) {

                return d.clinics;
            }
        }
    });

    function autocompleteClinicDefaults(q, sync, async) {
        if (q === '') {
            autocompleteClinic.search('dahiliye', sync);
        } else {
            autocompleteClinic.search(q, sync, async);
        }
    }

    //####### Input Init #########
    let doctor_template = Handlebars.compile($("#search-result-template").html());
    let branch_template = Handlebars.compile($("#search-result-branch-template").html());
    let disease_template = Handlebars.compile($("#search-result-disease-template").html());
    let treatment_template = Handlebars.compile($("#search-result-treatment-template").html());
    
    $('.searchList').typeahead({
            minLength: 0,
            highlight: true
        },
        {
            name: 'DoctorList',
            source: autocompleteDoctorDefaults,
            displayKey: 'name',
            templates: {
                empty: '<div class="suggest-district-menu">Aradığınız kritere uygun kayıt bulunamamıştır.</div>',
                header: '<div class="suggest-district-menu">Doktorlar</div>',
                suggestion: doctor_template
            }
        },
        {
            name: 'BranchList',
            display: 'name',
            source: autocompleteBranchDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Branşlar</div>',
                suggestion: branch_template
            }
        },
        {
            name: 'ClinicList',
            display: 'name',
            source: autocompleteClinicDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Hastaneler</div>'
            }
        },
        {
            name: 'DiseaseList',
            display: 'name',
            source: autocompleteDiseaseDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Hastalıklar</div>',
                suggestion: disease_template
            }
        },
        {
            name: 'TreatmentList',
            display: 'name',
            source: autocompleteTreatmentDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Tedavi Yöntemleri</div>',
                suggestion: treatment_template
            }
        }).on('typeahead:asyncrequest', function () {


        $('.searchList.tt-hint').css('background-image', 'url("https://loading.io/mod/spinner/dna/sample.gif")');
        $('.tt-hint').css('background-repeat', 'no-repeat').css('background-size', 'fill').css('background-position', 'right');

    }).on('typeahead:asynccancel typeahead:asyncreceive', function () {

        $('.tt-hint').css('background-image', '');
    });
}

function doctorClick(id) {

    window.location.href = '/doctor/doctorDetail?id=' + id;
}