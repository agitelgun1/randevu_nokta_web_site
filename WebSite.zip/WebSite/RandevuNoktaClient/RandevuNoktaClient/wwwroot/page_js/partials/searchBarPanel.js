﻿function searchBarPanelInit() {
    initAutoComplete();
    defaultEnterEvents();
}

function defaultEnterEvents() {

    var input = document.getElementsByClassName("searchList");

    input[1].addEventListener("keyup", function (event) {
        if (event.keyCode === 13) {
            btnClinicSearchInputClick();
        }
    });
}

function btnClinicSearchInputClick() {
    var term = $('.searchList').val();
    if (term === null || term === "") {
        window.location.href ='/hospital/list?term=' + term;
    } else {
        window.location.href = '/doctor/list?term=' + term;
    }
}

function btnClinicSearchClick(term) {

    window.location.href = '/doctor/list?term=' + term;
}

function initAutoComplete() {
    //#### SearchFields Init #######
    var autocompleteDoctor = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        dupDetector: function (a, b) {
            return a.id_str === b.id_str;
        },
        remote: {
            url: 'Search/AutoComplete?q=%QUERY',
            wildcard: '%QUERY',
            transform: function (d) {

                return d.doctors;
            }
        }
    });

    function autocompleteDoctorDefaults(q, sync, async) {

        if (q === '') {
            autocompleteDoctor.search('dahiliye', sync, async)
        } else {
            autocompleteDoctor.search(q, sync, async);
        }
    }

    var autocompleteBranch = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        limit: 100,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY',
            wildcard: '%QUERY',
            transform: function (d) {
                return d.branches;
            }
        }
    });

    function autocompleteBranchDefaults(q, sync, async) {
        if (q === '') {
            autocompleteBranch.search('dahiliye', sync, async);
        } else {
            autocompleteBranch.search(q, sync, async);
        }
    }

    var autocompleteDisease = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY',
            wildcard: '%QUERY',
            transform: function (d) {

                return d.diseases;
            }
        }
    });

    function autocompleteDiseaseDefaults(q, sync, async) {
        if (q === '') {
            autocompleteDisease.search('dahiliye', sync, async);
        } else {
            autocompleteDisease.search(q, sync, async);
        }
    }

    var autocompleteTreatment = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY',
            wildcard: '%QUERY',
            transform: function (d) {

                return d.treatments;
            }
        }
    });

    function autocompleteTreatmentDefaults(q, sync, async) {
        if (q === '') {
            autocompleteTreatment.search('dahiliye', sync, async);
        } else {
            autocompleteTreatment.search(q, sync, async);
        }
    }

    var autocompleteClinic = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.whitespace,
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: 'Search/AutoComplete?q=%QUERY',
            wildcard: '%QUERY',
            transform: function (d) {

                return d.clinics;
            }
        }
    });

    function autocompleteClinicDefaults(q, sync, async) {
        if (q === '') {
            autocompleteClinic.search('dahiliye', sync);
        } else {
            autocompleteClinic.search(q, sync, async);
        }
    }

    //####### Input Init #########
    var doctor_template = Handlebars.compile($("#search-result-template").html());
    var branch_template = Handlebars.compile($("#search-result-branch-template").html());
    var disease_template = Handlebars.compile($("#search-result-disease-template").html());
    var treatment_template = Handlebars.compile($("#search-result-treatment-template").html());

    $('.searchList').typeahead({
            minLength: 0,
            highlight: true
        },
        {
            name: 'DoctorList',
            source: autocompleteDoctorDefaults,
            displayKey: 'name',
            templates: {
                header: '<div class="suggest-district-menu">Doktorlar</div>',
                suggestion: doctor_template
            }
        },
        {
            name: 'BranchList',
            display: 'name',
            source: autocompleteBranchDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Branşlar</div>',
                suggestion: branch_template
            }
        },
        {
            name: 'ClinicList',
            display: 'name',
            source: autocompleteClinicDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Hastaneler</div>'
            }
        },
        {
            name: 'DiseaseList',
            display: 'name',
            source: autocompleteDiseaseDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Hastalıklar</div>',
                suggestion: disease_template
            }
        },
        {
            name: 'TreatmentList',
            display: 'name',
            source: autocompleteTreatmentDefaults,
            templates: {
                header: '<div class="suggest-district-menu">Tedavi Yöntemleri</div>',
                suggestion: treatment_template
            }
        }).on('typeahead:asyncrequest', function () {


        $('.searchList.tt-hint').css('background-image', 'url("https://loading.io/mod/spinner/dna/sample.gif")');
        $('.tt-hint').css('background-repeat', 'no-repeat').css('background-size', 'fill').css('background-position', 'right');

    }).on('typeahead:asynccancel typeahead:asyncreceive', function () {

        $('.tt-hint').css('background-image', '');
    });
}

function doctorClick(id) {

    window.location.href = '/doctor/doctorDetail?id=' + id;
}