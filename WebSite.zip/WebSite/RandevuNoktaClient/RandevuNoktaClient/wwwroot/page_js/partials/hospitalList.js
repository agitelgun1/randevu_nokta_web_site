var urlParams = new URLSearchParams(window.location.search);
var term = urlParams.get('term');

var cityId = localStorage.getItem("cityId");
var districtId = localStorage.getItem("districtId");
var allClinicCount = 0;
var clinicList = [];

function clinicListInit() {
    initClinicListComponents();
}

function initMap(locations) {
    document.getElementById('sidebar').innerHTML = "<div id='map_listing' class='normal_list'></div>";
    var map = L.map('map_listing').setView([locations[0].x, locations[0].y], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    $.each(locations, function (i, val) {

        L.marker([val.x, val.y])
            .bindPopup("<b>"+val.title+"</b>").openPopup()
            .addTo(map);
    });

}

function initClinicListComponents() {
    GetAllClinicList();
}

function GetAllClinicList() {
    $.ajax({
        type: "GET",
        url: "/Search/clinicsearchwithoutterm?cityId=" + cityId + '&districtId=' + districtId + '&term=' + term,
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        cache: false,
        success: function (result) {
            if (result !== undefined && result !== null) {
                allHospitalClinicListRender(result);
                hospitalPaginationRender(1, result);
                makeActiveListElementsOnClick();
            }
        }
    });
}

function GetClinicList(pageIndex, pageSize) {
    var isActive = document.getElementById("current-page-" + pageIndex).classList.contains('active');
    if (isActive) {
        return;
    }
    var page = 10 * (pageIndex - 1);
    var data = $.extend({}, clinicList.slice(page, page + pageSize));
    hospitalClinicListRender(data);
    makeActiveListElementsOnClick();
    hospitalPaginationRender(pageIndex, data);
}

function hospitalClick(id) {

    window.location.href = "/hospital/hospitalDetail?clinicId=" + id;
}

function hospitalDoctorListRender(data) {

    var source = document.getElementById("hospital-doctor-list-template").innerHTML;
    var template = Handlebars.compile(source);

    $('#hospital_doctor_list_info_box').html(template(data));
}

function hospitalShowingInfoRender(clinicCount) {
    var template = '<h4>Toplam ' + allClinicCount + ' hastaneden <strong>' + clinicCount + ' tane gösterim yapılmaktadır.</strong></h4>';

    $('#hospital_showing_info_box').html(template);
}

function allHospitalClinicListRender(data) {

    var source = document.getElementById("hospital-list-template").innerHTML;
    var template = Handlebars.compile(source);
    var locations = [];
    var html = "";
    var firstTen = 0; //sayfa yuklenirken ilk 10 tane elemani almak icin yapildi.
    var clinicCount = 0;

    $.each(data, function (i, val) {
        if (firstTen < 10) {
            html += template(val);
            locations.push({x: val.lat, y: val.lng, title: val.name});
            clinicCount++;
        }
        allClinicCount++;
        clinicList.push(val);
        firstTen++;
    });

    hospitalShowingInfoRender(clinicCount);
    initMap(locations);
    $('#clinic_list_wrapper').html(html);
}

function hospitalClinicListRender(data) {

    var source = document.getElementById("hospital-list-template").innerHTML;
    var template = Handlebars.compile(source);
    var locations = [];
    var html = "";
    var clinicCount = 0;

    $.each(data, function (i, val) {
        html += template(val);
        locations.push({x: val.lat, y: val.lng});
        clinicCount++;

    });

    hospitalShowingInfoRender(clinicCount);
    initMap(locations);
    $('#clinic_list_wrapper').html(html);
}

function hospitalPaginationRender(currentPage, result) {
    if ((result !== null && result.length > 0) || Object.keys(result).length) {
        var source = document.getElementById("hospital-pagination-template").innerHTML;

        var template = Handlebars.compile(source);

        var context = {
            "currentPage": currentPage,
            "pageCount": Math.ceil(clinicList.length / 10),
            "size": 9
        };

        $('#hospital_pagination_box').html(template(context));
    }
}

function makeActiveListElementsOnClick() {
    $('#hospital-pagination').on('click', 'li', function () {
        $(this).addClass('page-item active').siblings().removeClass('active');
    });
}