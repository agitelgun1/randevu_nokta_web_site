var input_tel = null;
var errorMsg_tel = null;
var validMsg_tel = null;
var iti = null;
var number = '';
var isValidTel = false;
var countryData = {};

function PageInit() {
    input_tel = document.querySelector("#phone");
    errorMsg_tel = document.querySelector("#error-msg");
    validMsg_tel = document.querySelector("#valid-messageg");

    errorMsg_tel.style.color = "red";
    validMsg_tel.style.color = "green";

    var errorMap_tel = ["Geçersiz numara", "Geçersiz ülke kodu", "Girilen telefon numarasının karakter sayısı çok kısa!",
        "Girilen telefon numarasının karakter sayısı çok uzun!", "Geçersiz numara", "Geçersiz numara", "Geçersiz numara"];
    iti = window.intlTelInput(input_tel, {
        dropdownContainer: document.body,
        localizedCountries: {'tr': 'Türkiye'},
        placeholderNumberType: "MOBILE",
        preferredCountries: ['tr', 'us'],
        utilsScript: "/js/utils.js",
    });
    var reset = function () {
        input_tel.classList.remove("error");
        errorMsg_tel.innerHTML = "";
        validMsg_tel.innerHTML = "";
        errorMsg_tel.classList.add("hide");
        validMsg_tel.classList.add("hide");
    };

    input_tel.addEventListener('blur', function () {
        reset();
        if (input_tel.value.trim()) {
            if (iti.isValidNumber()) {
                isValidTel = true;
                validMsg_tel.classList.remove("hide");
                validMsg_tel.innerHTML = '<br/>✓ Geçerli';
            } else {
                isValidTel = false;
                input_tel.classList.add("error");
                var errorCode = iti.getValidationError();

                errorMsg_tel.innerHTML = '<br/>' + errorMap_tel[errorCode];
                errorMsg_tel.classList.remove("hide");
            }
        }
    });

// on keyup / change flag: reset
    input_tel.addEventListener('change', reset);
    input_tel.addEventListener('keyup', reset);
}


function makeAppointment() {
    let name = $('#txtName').val();
    let surname = $('#txtSurname').val();
    let contracts = $("#contractsCheckBox").is(':checked');
    let appointmentType = $('#appointment-type').val();
    let description = $('#txtInformation').val();

    number = iti.getNumber();
    countryData = iti.getSelectedCountryData();

    if (name === "" || name === undefined) {
        document.getElementById("msgName").innerHTML = "<br/>Lütfen adınızı giriniz!";
        document.getElementById("msgName").style.color = "red";
        return;
    }

    if (surname === "" || surname === undefined) {
        document.getElementById("msgSurname").innerHTML = "<br/>Lütfen soy adınızı giriniz!";
        document.getElementById("msgSurname").style.color = "red";
        return;
    }

    if (number === "" || number === undefined || isValidTel === false) {
        document.getElementById("msgTel").innerHTML = "<br/>Lütfen telefon numaranızı giriniz!";
        document.getElementById("msgTel").style.color = "red";
        return;
    }
    if (appointmentType === "" || appointmentType === undefined) {
        document.getElementById("msgAppointmentType").innerHTML = "<br/>Lütfen muayane tipinizi giriniz!";
        document.getElementById("msgAppointmentType").style.color = "red";
        return;
    }
    if (description === "" || description === undefined) {
        document.getElementById("msgInformation").innerHTML = "<br/>Lütfen yorumunuzu yazınız!";
        document.getElementById("msgInformation").style.color = "red";
        return;
    }
    if (!contracts) {
        document.getElementById("msgContracts").innerHTML = "<br/>Lütfen Kullanım sözleşmesini ve Gizlilik politikasini onaylayiniz!";
        document.getElementById("msgContracts").style.color = "red";
        return;
    }
    //TODO:Servisler yazıldıktan sonra ajax call düzeltilecek
    return;
    $.ajax({
        type: "POST",
        url: "/auth/register",
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        data: JSON.stringify(registerObj),
        success: function (result) {

            if (result !== undefined && result !== null && result.token !== '') {

                Notiflix.Notify.Success('Hesabınız başarıyla oluşturuldu.');
                Notiflix.Notify.Success('Giriş sayfasına yönlendiriliyorsunuz...');

                document.getElementById("btnConfirm").style.pointerEvents = "auto";
                setInterval(function () {

                    window.location.href = '/auth/login';
                }, 1500);
            }
        },
        error: function (result) {
            document.getElementById("btnAppointment").style.pointerEvents = "auto";
            var errorValue = jQuery.parseJSON(result.responseText).errorDescription;

            if (result !== undefined && result !== null && errorValue !== '') {
                toastr.warning(errorValue, 'Dikkat!');
                return;
            }
            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
}

function validateNameText(text) {
    if (text.length !== 0) {
        document.getElementById("msgName").innerHTML = "";
    }
}

function validateSurnameText(text) {
    if (text.length !== 0) {
        document.getElementById("msgSurname").innerHTML = "";
    }
}

function validateTel(text) {
    if (text.length !== 0) {
        document.getElementById("msgTel").innerHTML = "";
    }
}

function checkContracts() {

    var contracts = $("#contractsCheckBox").is(':checked');

    if (contracts) {
        document.getElementById("msgContracts").innerHTML = "";
    }
}

function validateInformationText(text) {
    if (text.length !== 0) {
        document.getElementById("msgInformation").innerHTML = "";
    }
}