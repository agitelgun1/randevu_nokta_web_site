var urlParams = new URLSearchParams(window.location.search);
var doctor_id = urlParams.get('id');
var selectedClinic;


function doctorCalendarRender() {

    if(selectedClinic !== undefined && selectedClinic !== null && selectedClinic > 0)
    {
        $.get('/Templates/Doctor/AppointmentCalenderTmp.html', function (source) {

            const template = Handlebars.compile(source);

            $('#calendar_box').html(template("data"));

            $('.appointment_calender').slick({
                arrows: true,
                nextArrow: '<a href="#" class="calendar_next_arrow"><i class="icon-angle-circled-right"></i></a>',
                prevArrow: '<a href="#" class="calendar_prev_arrow"><i class="icon-angle-circled-left"></i></a>',
                dots:false,
                autoplay:false,
                infinite:false
            });

        }, 'html');
    }
    else
    {
        var d= {};
        d.text = "Lütfen önce hastane seçiniz.";

        var source = document.getElementById("dark-alert-box-template").innerHTML;
        var template = Handlebars.compile(source);

        $('#calendar_box').html(template(d));
    }

}

function clinicSelectOnClick(clinicId) {

    $('.clinicListCheckBox').prop('checked', false);
    $('#clinic_' + clinicId).prop('checked', true);

    selectedClinic = clinicId;
    doctorCalendarRender();

}