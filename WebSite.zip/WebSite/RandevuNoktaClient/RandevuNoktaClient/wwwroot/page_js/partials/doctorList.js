var urlParams = new URLSearchParams(window.location.search);
var term = urlParams.get('term');
var clinicList = [];
var allDoctorCount = 0;

function doctorListInit() {
    initDoctorListComponents();
}

function initMap(locations) {
    document.getElementById('sidebar').innerHTML = "<div id='map_listing' class='normal_list'></div>";
    var map = L.map('map_listing').setView([locations[0].x, locations[0].y], 15);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    $.each(locations, function (i, val) {

        L.marker([val.x, val.y])
            .bindPopup("<b>"+val.title+"</b>").openPopup()
            .addTo(map);
    });

}

function initDoctorListComponents() {
    GetClinicList();
}

function GetClinicList() {

    var cityId = localStorage.getItem("cityId");
    var districtId = localStorage.getItem("districtId");

    $.ajax({
        type: "GET",
        url: "/Search/clinicsearch?cityId=" + cityId + '&districtId=' + districtId + '&term=' + term,
        contentType: "application/json; charset=utf-8",
        timeout: 9000,
        cache: false,
        success: function (result) {
            if (result !== undefined && result !== null) {
                hospitalDoctorListRender(result);
                doctorPaginationRender(1, result);
            }
        }
    });
}

//Html tarafindan gelen istekler icin olusturuldu bu fonksiyon (pagination). GetClinicList() fonskyionu ile tum liste cekiliyor  bu liste icinde pagination yapiyoruz.
function GetClinicListByPageIndex(pageIndex, pageSize) {
    var isActive = document.getElementById("current-page-" + pageIndex).classList.contains('active');

    if (isActive) {
        return;
    }

    var page = 10 * (pageIndex - 1);
    var data = $.extend({}, clinicList.slice(page, page + pageSize));
    hospitalDoctorListRender2(data);
    makeActiveListElementsOnClick();
    doctorPaginationRender(pageIndex, data);
}

function hospitalClick(id) {

    window.location.href = "/hospital/hospitalDetail?clinicId=" + id;
}

function doctorClick(id) {

    window.location.href = '/doctor/doctorDetail?id=' + id;
}

function doctorShowingInfoRender(doctorCount) {
    var template = '<h4>Toplam ' + allDoctorCount + ' doktordan <strong>' + doctorCount + ' tane gösterim yapılmaktadır.</strong></h4>';

    $('#doctor_showing_info_box').html(template);
}

function doctorPaginationRender(currentPage, result) {
    if ((result !== null && result.length > 0) || Object.keys(result).length) {
        var source = document.getElementById("doctor-pagination-template").innerHTML;

        var template = Handlebars.compile(source);
        var doctorCount = 0;

        $.each(result, function (i, val) {
            if (val.doctors !== null && val.doctors.length > 0) {
                doctorCount++;
            }
        });

        var context = {
            "currentPage": currentPage,
            "pageCount": Math.ceil(doctorCount / 10),
            "size": 9
        };

        $('#doctor_pagination_box').html(template(context));
    }
}

function makeActiveListElementsOnClick() {
    var $lis = $('.doctor-pagination > li').click(function () {
        $lis.removeClass('active');
        $(this).addClass('active')
    });
}

function hospitalDoctorListRender(data) {

    var source = document.getElementById("search-doctor-list-template").innerHTML;
    var template = Handlebars.compile(source);
    var html = "";
    var firstTen = 0; //sayfa yuklenirken ilk 10 tane elemani almak icin yapildi.
    var doctorCount = 0;
    var locations = [];

    $.each(data, function (i, val) {
        if (val.doctors !== null && val.doctors.length > 0) {
            if (firstTen < 10) {
                html += template(val);
                locations.push({x: val.lat, y: val.lng, title: val.name});
                doctorCount = doctorCount + val.doctors.length
            }
            clinicList.push(val);
            firstTen++;
            allDoctorCount = allDoctorCount + val.doctors.length;
        }
    });
    doctorShowingInfoRender(doctorCount);

    initMap(locations);
    $('#doctor_list_wrapper').html(html);
}

function hospitalDoctorListRender2(data) {

    var source = document.getElementById("search-doctor-list-template").innerHTML;
    var template = Handlebars.compile(source);
    var html = "";
    var doctorCount = 0;

    var locations = [];

    $.each(data, function (i, val) {
        if (val.doctors !== null && val.doctors.length > 0) {
            html += template(val);
            locations.push({x: val.lat, y: val.lng});
            doctorCount = doctorCount + val.doctors.length
        }
    });
    doctorShowingInfoRender(doctorCount);


    initMap(locations);
    $('#doctor_list_wrapper').html(html);
}