function PageInit() {

    userInfoRender();
    userPasswordRender();
}

function userInfoRender() {

    let data = {};
    let source = document.getElementById("user-info-template").innerHTML;
    let template = Handlebars.compile(source);

    $('#user_info_box').html(template(data));
}

function userPasswordRender() {

    let data = {};
    let source = document.getElementById("user-password-template").innerHTML;
    let template = Handlebars.compile(source);

    $('#user_password_box').html(template(data));
}

function resetPasswordClick() {

    var changePassword = {};

    changePassword.password = $('#txtNewPassword').val();
    changePassword.passwordConfirm = $('#txtNewPasswordConfirm').val();

    if (changePassword.password === '') {
        toastr.error('Lütfen şifre alanını doldurunuz!', 'İşlem Başarısız');
        return false;
    } else if (changePassword.passwordConfirm === '') {
        toastr.error('Lütfen şifre tekrar alanını doldurunuz!', 'İşlem Başarısız');
        return false;
    } else if (changePassword.password !== changePassword.passwordConfirm) {
        toastr.error('Girilen şifreler uyumsuzdur!', 'İşlem Başarısız');
        return false;
    }

    var hash = getParameterByName('hash');

    var changePasswordObj = {};
    changePasswordObj.Hash = hash;
    changePasswordObj.Password = changePassword.password;

    if (changePasswordObj.Hash === null){
        return;
    }
    $.ajax({
        type: "POST",
        url: "/auth/changeforgotpassword",
        contentType: "application/json; charset=utf-8",
        timeout: 7000,
        data: JSON.stringify(changePasswordObj),
        success: function (result) {
            Notiflix.Notify.Success('Şifreniz başarılı bir şekilde değiştirildi!');
            Notiflix.Notify.Success('Giriş sayfasına yönlendiriliyorsunuz...');

            setInterval(function () {
                window.location.href = '/auth/login';
            }, 2000);
        },
        error: function (result) {
            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

function validatePassword(password) {
    // Do not show anything when the length of password is zero.
    if (password.length === 0) {
        document.getElementById("msg").innerHTML = "";
        return;
    }
    // Create an array and push all possible values that you want in password
    var matchedCase = new Array();
    matchedCase.push("[$@$!%*#?&-_=+()%^]"); // Special Charector
    matchedCase.push("[A-Z]");      // Uppercase Alpabates
    matchedCase.push("[0-9]");      // Numbers
    matchedCase.push("[a-z]");     // Lowercase Alphabates
    // Check the conditions
    var ctr = 0;
    for (var i = 0; i < matchedCase.length; i++) {
        if (new RegExp(matchedCase[i]).test(password)) {
            ctr++;
        }
    }
    // Display it
    var color = "";
    var strength = "";
    switch (ctr) {
        case 0:
        case 1:
        case 2:
        case 3:
            strength = "<br/>Zayıf!<br/> Şifreniz 8 karakter uzunluğunda, en az bir büyük harf, ,en az bir küçük harf, en az bir sayı, en az bir özel karakter içermelidir(+, &, @ vb.)";
            color = "red";
            document.getElementById("resetPasswordConfirm").style.pointerEvents = "none";
            break;
        case 4:
            if (password.length < 8) {
                strength = "<br/>Zayıf!<br/> Şifreniz 8 karakter uzunluğunda, en az bir büyük harf, ,en az bir küçük harf, en az bir sayı, en az bir özel karakter içermelidir (+, &, @ vb.)";
                color = "red";
                document.getElementById("resetPasswordConfirm").style.pointerEvents = "none";
                break;
            }
            strength = "<br/>Güçlü";
            color = "green";
            document.getElementById("resetPasswordConfirm").style.pointerEvents = "auto";
            break;
    }
    document.getElementById("msg").innerHTML = strength;
    document.getElementById("msg").style.color = color;
}
