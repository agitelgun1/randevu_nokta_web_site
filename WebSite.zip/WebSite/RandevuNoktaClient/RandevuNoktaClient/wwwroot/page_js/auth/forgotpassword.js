﻿function PageInit() {

}


function forgotPasswordClick() {

    var loginRequest = {};

    loginRequest.Email = $('#txtEmail').val();
    
    $.ajax({
        type: "POST",
        url: "/auth/forgotpassword",
        contentType: "application/json; charset=utf-8",
        data: JSON.stringify(loginRequest),
        timeout: 9000,
        success: function (result) {

            if (result !== undefined && result !== null && result.token !== '') {

                toastr.success('Mail sağlıklı bir şekilde size ulaşacaktır!', 'İşlem Başarılı');

                setInterval(function () {

                    window.location.href = '/auth/login';
                }, 2000);
            }
        },
        error: function (result) {
            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
}

