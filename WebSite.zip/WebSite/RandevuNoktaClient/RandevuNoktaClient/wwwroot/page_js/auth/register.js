var input_tel = null;
var errorMsg_tel= null;
var validMsg_tel = null;
var iti = null;
var number = '';
var isValidTel = false;
var countryData = {};

function PageInit() {
    document.getElementById("btnConfirm").style.pointerEvents = "none";

    input_tel = document.querySelector("#phone");
    errorMsg_tel = document.querySelector("#error-msg");
    validMsg_tel = document.querySelector("#valid-messageg");

    errorMsg_tel.style.color = "red";
    validMsg_tel.style.color = "green";

    var errorMap_tel = ["Geçersiz numara", "Geçersiz ülke kodu", "Girilen telefon numarasının karakter sayısı çok kısa!",
        "Girilen telefon numarasının karakter sayısı çok uzun!", "Geçersiz numara","Geçersiz numara","Geçersiz numara"];
    iti = window.intlTelInput(input_tel, {
        // allowDropdown: false,
        // autoHideDialCode: false,
        // autoPlaceholder: "off",
        dropdownContainer: document.body,
        // excludeCountries: ["us"],
        // formatOnDisplay: false,
        // geoIpLookup: function(callback) {
        //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
        //     var countryCode = (resp && resp.country) ? resp.country : "";
        //     callback(countryCode);
        //   });
        // },
        // hiddenInput: "full_number",
        // initialCountry: "auto",
        localizedCountries: { 'tr': 'Türkiye' },
        // nationalMode: false,
        // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
        placeholderNumberType: "MOBILE",
        preferredCountries: ['tr', 'us'],
        // separateDialCode: true,
        utilsScript: "/js/utils.js",
    });
    var reset = function() {
        input_tel.classList.remove("error");
        errorMsg_tel.innerHTML = "";
        validMsg_tel.innerHTML="";
        errorMsg_tel.classList.add("hide");
        validMsg_tel.classList.add("hide");
    };

    input_tel.addEventListener('blur', function() {
        reset();
        if (input_tel.value.trim()) {
            if (iti.isValidNumber()) {
                isValidTel = true;
                validMsg_tel.classList.remove("hide");
                validMsg_tel.innerHTML = '<br/>✓ Geçerli';
            } else {
                isValidTel=false;
                input_tel.classList.add("error");
                var errorCode = iti.getValidationError();

                errorMsg_tel.innerHTML = '<br/>' + errorMap_tel[errorCode];
                errorMsg_tel.classList.remove("hide");
            }
        }
    });

// on keyup / change flag: reset
    input_tel.addEventListener('change', reset);
    input_tel.addEventListener('keyup', reset);
}

function registerUser() {

    var password = $('#txtPassword').val();
    var passwordConfirm = $('#txtPasswordConfirm').val();
    var name = $('#txtName').val();
    var surname = $('#txtSurname').val();
    var email = $('#txtEmail').val();
    var contracts = $("#contractsCheckBox").is(':checked');
    number = iti.getNumber();
    countryData = iti.getSelectedCountryData();


    if (name === "" || name === undefined) {
        document.getElementById("msgName").innerHTML = "<br/>Lütfen adınızı giriniz!";
        document.getElementById("msgName").style.color = "red";
        return;
    }

    if (surname === "" || surname === undefined) {
        document.getElementById("msgSurname").innerHTML = "<br/>Lütfen soy adınızı giriniz!";
        document.getElementById("msgSurname").style.color = "red";
        return;
    }

    if (email === "" || email === undefined) {
        document.getElementById("msgEmailCheck").innerHTML = "<br/>Lütfen email adresinizi giriniz!";
        document.getElementById("msgEmailCheck").style.color = "red";
        return;
    }

    if (number === "" || number === undefined || isValidTel === false) {
        document.getElementById("msgTel").innerHTML = "<br/>Lütfen telefon numaranızı giriniz!";
        document.getElementById("msgTel").style.color = "red";
        return;
    }
    if (password === "" || password === undefined) {
        document.getElementById("msg").innerHTML = "<br/>Lütfen şifre giriniz!";
        document.getElementById("msg").style.color = "red";
        return;

    }
    if (passwordConfirm === "" || passwordConfirm === undefined) {
        document.getElementById("msgPasswordConfirm").innerHTML = "<br/>Lütfen şifre tekrar giriniz!";
        document.getElementById("msgPasswordConfirm").style.color = "red";
        return;
    }
    if (!contracts) {
        document.getElementById("msgContracts").innerHTML = "<br/>Lütfen Kullanım sözleşmesini ve Gizlilik politikasini onaylayiniz!";
        document.getElementById("msgContracts").style.color = "red";
        return;
    }
    if (password === passwordConfirm) {

        var registerObj = {};

        registerObj.Name = $('#txtName').val();
        registerObj.Surname = $('#txtSurname').val();
        registerObj.Email = $('#txtEmail').val();
        registerObj.Phone = $('#txtTel').val();
        registerObj.Password = password;
        registerObj.IsActive = true;
        registerObj.IsDeleted = false;

        if (name === "" || name === undefined || surname === "" || surname === undefined || email === "" || email === undefined ||
            password === "" || password === undefined || passwordConfirm === "" || passwordConfirm === undefined ||
            number === "" || number === undefined || isValidTel === false) {
            return;
        }
        //Multiple click kapatilmasi icin bu konuldu!
        document.getElementById("btnConfirm").style.pointerEvents = "none";

        $.ajax({
            type: "POST",
            url: "/auth/register",
            contentType: "application/json; charset=utf-8",
            timeout: 9000,
            data: JSON.stringify(registerObj),
            success: function (result) {

                if (result !== undefined && result !== null && result.token !== '') {

                    Notiflix.Notify.Success('Hesabınız başarıyla oluşturuldu.');
                    Notiflix.Notify.Success('Giriş sayfasına yönlendiriliyorsunuz...');

                    document.getElementById("btnConfirm").style.pointerEvents = "auto";
                    setInterval(function () {

                        window.location.href = '/auth/login';
                    }, 1500);
                }
            },
            error: function (result) {
                document.getElementById("btnConfirm").style.pointerEvents = "auto";
                var errorValue = jQuery.parseJSON(result.responseText).errorDescription;

                if (result !== undefined && result !== null && errorValue !== '') {
                    toastr.warning(errorValue, 'Dikkat!');
                    return;
                }
                toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
            }
        });
    } else {

        Notiflix.Notify.Failure('Şifre ve şifre tekrarı uyumsuz');
    }
}

function validatePassword(password) {
    // Do not show anything when the length of password is zero.
    if (password.length === 0) {
        document.getElementById("msg").innerHTML = "";
        return;
    }
    // Create an array and push all possible values that you want in password
    var matchedCase = new Array();
    matchedCase.push("[$@$!%*#?&-_=+()%^]"); // Special Charector
    matchedCase.push("[A-Z]");      // Uppercase Alpabates
    matchedCase.push("[0-9]");      // Numbers
    matchedCase.push("[a-z]");     // Lowercase Alphabates
    // Check the conditions
    var ctr = 0;
    for (var i = 0; i < matchedCase.length; i++) {
        if (new RegExp(matchedCase[i]).test(password)) {
            ctr++;
        }
    }
    // Display it
    var color = "";
    var strength = "";
    switch (ctr) {
        case 0:
        case 1:
        case 2:
        case 3:
            strength = "<br/>Zayıf!<br/> Şifreniz 8 karakter uzunluğunda, en az bir büyük harf, ,en az bir küçük harf, en az bir sayı, en az bir özel karakter içermelidir(+, &, @ vb.)";
            color = "red";
            document.getElementById("btnConfirm").style.pointerEvents = "none";
            break;
        case 4:
            if (password.length < 8) {
                strength = "<br/>Zayıf!<br/> Şifreniz 8 karakter uzunluğunda, en az bir büyük harf, ,en az bir küçük harf, en az bir sayı, en az bir özel karakter içermelidir (+, &, @ vb.)";
                color = "red";
                document.getElementById("btnConfirm").style.pointerEvents = "none";
                break;
            }
            strength = "<br/>Güçlü";
            color = "green";
            document.getElementById("btnConfirm").style.pointerEvents = "auto";
            break;
    }
    document.getElementById("msg").innerHTML = strength;
    document.getElementById("msg").style.color = color;
}

function validateEmail(email) {
    if (email.length === 0) {
        document.getElementById("msgEmailCheck").innerHTML = "";
        return;
    }
    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var isEmailAvailable = emailRegex.test(email);

    if (!isEmailAvailable) {
        document.getElementById("msgEmailCheck").innerHTML = "<br/>Lütfen geçerli bir email adresi giriniz!";
        document.getElementById("msgEmailCheck").style.color = "red";
    } else {
        document.getElementById("msgEmailCheck").innerHTML = "<br/>Email adresi geçerli!";
        document.getElementById("msgEmailCheck").style.color = "green";
    }
}

function validateNameText(text) {
    if (text.length !== 0) {
        document.getElementById("msgName").innerHTML = "";
    }
}

function validateSurnameText(text) {
    if (text.length !== 0) {
        document.getElementById("msgSurname").innerHTML = "";
    }
}

function validateTel(text) {
    if (text.length !== 0) {
        document.getElementById("msgTel").innerHTML = "";
    }
}

function validatePasswordConfirm(text) {
    var password = $('#txtPassword').val();
    var passwordConfirm = $('#txtPasswordConfirm').val();

    if (text.length !== 0) {
        document.getElementById("msgPasswordConfirm").innerHTML = "";
    }

    if (password === "" || password === undefined || passwordConfirm === "" || passwordConfirm === undefined || password !== passwordConfirm) {
        document.getElementById("msgPasswordConfirm").innerHTML = "<br/>Şifre ile şifre tekrarı uyumsuzdur!";
        document.getElementById("msgPasswordConfirm").style.color = "red";
    } else {
        document.getElementById("msgPasswordConfirm").innerHTML = "<br/>Şifre ile şifre tekrarı uyumlu";
        document.getElementById("msgPasswordConfirm").style.color = "green";
    }
}

function checkContracts() {

    var contracts = $("#contractsCheckBox").is(':checked');

    if (contracts) {
        document.getElementById("msgContracts").innerHTML = "";
    }
}