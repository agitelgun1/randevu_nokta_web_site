﻿function PageInit() {
    document.getElementById('error-msg-box').style.display = 'none';
    document.getElementById('btnLogin').style.pointerEvents = 'none';
}


function loginClick() {

    var loginRequest = {};

    loginRequest.Email = $('#txtEmail').val();
    loginRequest.Password = $('#txtPassword').val();
    
    if (loginRequest.Email === "" || loginRequest.Email === undefined) {
        document.getElementById("msgEmailCheck").innerHTML = "<br/>Lütfen email giriniz!";
        document.getElementById("msgEmailCheck").style.color = "red";
    }
    if (loginRequest.Password === "" || loginRequest.Password === undefined) {
        document.getElementById("msgPassword").innerHTML = "<br/>Lütfen şifre giriniz!";
        document.getElementById("msgPassword").style.color = "red";
        return;
    }

    if (loginRequest.Email === "" || loginRequest.Email === undefined || loginRequest.Password === "" || loginRequest.Password === undefined) {
        return;
    }

    if('abc' === 'abc'){
        
    }
    $.ajax({
        type: "POST",
        url: "/auth/login",
        contentType: "application/json; charset=utf-8",
        timeout: 6000,
        data: JSON.stringify(loginRequest),
        success: function (result) {

            if (result !== undefined && result !== null && result.token !== '') {

                toastr.success('Kullanıcı girişi başarı ile gerçekleşti.', 'İşlem Başarılı');

                window.location.href = '/home/index';
            }
        },
        error: function (result) {
            var errorValue = jQuery.parseJSON(result.responseText).userMesssage;

            if (result !== undefined && result !== null && errorValue !== '') {
                //Ajax setup.js dosyasinda hata mesaji veriliyor.
                document.getElementById('error-msg-box').style.display = 'block';
                return;
            }
            toastr.error('Bir hata ile karşılaşıldı!', 'Hata!');
        }
    });
}

function validateEmail(email) {
    if (email.length === 0) {
        document.getElementById("msgEmailCheck").innerHTML = "";
        return;
    }
    var emailRegex  = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var isEmailAvailable = emailRegex.test(email);

    if (!isEmailAvailable){
        document.getElementById("msgEmailCheck").innerHTML = "<br/>Lütfen geçerli bir email adresi giriniz!";
        document.getElementById("msgEmailCheck").style.color = "red";
    }
    else{
        document.getElementById('btnLogin').style.pointerEvents = 'auto';
        document.getElementById("msgEmailCheck").innerHTML = "";
    }
}

function passwordEntered(password) {
    if (password.length > 0) {
        document.getElementById("msgPassword").innerHTML = "";
        return;
    }
}
