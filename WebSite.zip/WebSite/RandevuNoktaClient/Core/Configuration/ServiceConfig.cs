﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Configuration
{
    public class ServiceConfig
    {
        public string Url { get; set; }
    }
}
