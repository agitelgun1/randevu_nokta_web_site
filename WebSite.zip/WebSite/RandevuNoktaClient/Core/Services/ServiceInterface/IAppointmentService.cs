namespace Core.Services.ServiceInterface
{
    public interface IAppointmentService
    {
        
    }
}