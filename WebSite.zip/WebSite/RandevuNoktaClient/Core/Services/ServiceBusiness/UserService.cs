using Core.Services.ServiceInterface;

namespace Core.Services.ServiceBusiness
{
    public class UserService : IUserService
    {
        
    }
}