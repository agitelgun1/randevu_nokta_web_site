﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.ViewModel
{
    public class PageAlert
    {
        public bool IsAlert { get; set; } = false;
        public string Message { get; set; } = "";
    }
}
