using System;
using System.Collections.Generic;
using Domain.Entity;
using Domain.ServiceModel;

namespace Domain.ViewModel
{
    public class AddDoctorCommentModel
    {
        public string Name { get; set; }
        public string Surname { get; set; }
    }
}