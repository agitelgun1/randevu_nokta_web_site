namespace Domain.ViewModel
{
    public class CommentScoreInfoModel
    {
        public double Score { get; set; }
        public int ReviewerCount { get; set; }
    }
}