namespace Domain.ServiceRequest.Auth
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}