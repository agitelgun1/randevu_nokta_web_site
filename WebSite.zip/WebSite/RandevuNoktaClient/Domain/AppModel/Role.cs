﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AppModel
{
    public class Role
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
