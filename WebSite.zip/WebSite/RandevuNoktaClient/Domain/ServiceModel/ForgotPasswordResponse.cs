namespace Domain.ServiceModel
{
    public class ForgotPasswordResponse 
    {
        public string IsMailSend { get; set; }
    }
}