namespace Domain.ServiceModel
{
    public class MailServiceResponse
    {
        
    }
}