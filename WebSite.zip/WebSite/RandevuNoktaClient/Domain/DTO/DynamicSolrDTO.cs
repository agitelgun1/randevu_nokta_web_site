namespace Domain.DTO
{
    public class DynamicSolrDTO : BaseCoreModel
    {
        public string Name { get; set; }
        public string Image { get; set; }
    }
}