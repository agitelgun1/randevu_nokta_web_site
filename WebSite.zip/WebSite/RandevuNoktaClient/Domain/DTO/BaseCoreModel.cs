namespace Domain.DTO
{
    public class BaseCoreModel
    {
        public string UniqueKey { get; set; }
        public int  Id { get; set; }
    }
}