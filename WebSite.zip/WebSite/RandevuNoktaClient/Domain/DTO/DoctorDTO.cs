namespace Domain.DTO
{
    public class DoctorDTO : BaseCoreModel
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Image { get; set; }
    }
}