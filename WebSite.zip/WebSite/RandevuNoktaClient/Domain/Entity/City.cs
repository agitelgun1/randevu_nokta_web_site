﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entity
{
    public class City
    {
        public int PlateCode { get; set; }
        public string Name { get; set; }
    }
}
